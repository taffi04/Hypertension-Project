
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier

# Load the synthetic demonstration dataset
df = pd.read_csv("synthetic_hypertension_demo.csv")

feature_columns = [
    "age",
    "smoking_status",
    "BMI",
    "salt_intake_score",
    "stress_score",
    "BP_history",
    "sleep_duration",
    "medication",
    "family_history",
    "exercise_level_score"
]

X = df[feature_columns]
y = df["hypertension_stage"]

categorical_columns = [
    "smoking_status",
    "BP_history",
    "medication",
    "family_history"
]

numeric_columns = [
    "age",
    "BMI",
    "salt_intake_score",
    "stress_score",
    "sleep_duration",
    "exercise_level_score"
]

# Use the same training split as before
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

# Build preprocessing and model pipeline
preprocessor = ColumnTransformer(
    transformers=[
        (
            "categorical",
            OneHotEncoder(handle_unknown="ignore"),
            categorical_columns
        ),
        ("numeric", "passthrough", numeric_columns)
    ]
)

model = Pipeline(
    steps=[
        ("preprocessing", preprocessor),
        (
            "classifier",
            RandomForestClassifier(
                n_estimators=100,
                random_state=42
            )
        )
    ]
)

# Train on the training set only
model.fit(X_train, y_train)

# Save the entire pipeline
joblib.dump(model, "hypertension_demo_model.joblib")

print("Model saved successfully!")
print("File: hypertension_demo_model.joblib")
print("Training records:", len(X_train))
print("Testing records reserved:", len(X_test))
print("Dataset: synthetic demonstration only")
