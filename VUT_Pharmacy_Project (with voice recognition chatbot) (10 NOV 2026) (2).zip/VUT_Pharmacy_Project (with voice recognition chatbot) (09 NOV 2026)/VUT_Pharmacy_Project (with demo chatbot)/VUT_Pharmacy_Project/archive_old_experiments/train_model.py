
import os
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report
)

# Locate the project folder
project_folder = os.path.dirname(os.path.abspath(__file__))

# Locate the hypertension dataset
dataset_path = os.path.join(
    project_folder,
    "Dataset",
    "Hypertension data set with lebeld by stage.csv"
)

# Load the dataset
df = pd.read_csv(dataset_path)

# Remove unnecessary spaces from column names
df.columns = df.columns.str.strip()

# Remove unnecessary spaces from hypertension stage labels
df["level"] = df["level"].astype(str).str.strip()

# Display basic dataset information
print("Dataset loaded successfully!")
print("Dataset shape:", df.shape)
print("\nColumn names:")
print(df.columns.tolist())

print("\nFirst five rows:")
print(df.head())

# Separate input features (X) from the target (y)
X = df.drop(columns=["level", "SBP"])
y = df["level"]

# Display the input and target information
print("\nInput features (X):")
print(X.columns.tolist())

print("\nTarget variable (y):")
print("level")

print("\nNumber of input features:", X.shape[1])
print("Number of target records:", y.shape[0])

print("\nHypertension stage counts:")
print(y.value_counts())

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

# Display the sizes of the datasets
print("\nTraining and testing split:")
print("Training input records:", X_train.shape[0])
print("Testing input records:", X_test.shape[0])
print("Training target records:", y_train.shape[0])
print("Testing target records:", y_test.shape[0])

# Create the Decision Tree model
decision_tree = DecisionTreeClassifier(
    random_state=42,
    class_weight="balanced"
)

# Train the model using the training data
decision_tree.fit(X_train, y_train)

print("\nDecision Tree model trained successfully!")

# Make predictions using the testing data
dt_predictions = decision_tree.predict(X_test)

# Calculate the model's accuracy
dt_accuracy = accuracy_score(y_test, dt_predictions)

print("\nDecision Tree Evaluation")
print("------------------------")
print(f"Accuracy: {dt_accuracy:.2%}")

# Display precision, recall, and F1-score for each category
print("\nClassification Report:")
print(classification_report(
    y_test,
    dt_predictions,
    zero_division=0
))

# Create the Random Forest model
random_forest = RandomForestClassifier(
    n_estimators=100,
    random_state=42,
    class_weight="balanced"
)

# Train the model
random_forest.fit(X_train, y_train)

print("\nRandom Forest model trained successfully!")

# Make predictions on the testing data
rf_predictions = random_forest.predict(X_test)

# Evaluate the model
rf_accuracy = accuracy_score(y_test, rf_predictions)

print("\nRandom Forest Evaluation")
print("------------------------")
print(f"Accuracy: {rf_accuracy:.2%}")

print("\nClassification Report:")
print(classification_report(
    y_test,
    rf_predictions,
    zero_division=0
))

# Compare the two models
print("\nMODEL COMPARISON")
print("----------------")

print(f"Decision Tree accuracy: {dt_accuracy:.2%}")
print(f"Random Forest accuracy: {rf_accuracy:.2%}")

# Examine the most influential Decision Tree features
print("\nDecision Tree Feature Importance")
dt_importance = pd.Series(
    decision_tree.feature_importances_,
    index=X.columns
).sort_values(ascending=False)

print(dt_importance)

# Examine the most influential Random Forest features
print("\nRandom Forest Feature Importance")
rf_importance = pd.Series(
    random_forest.feature_importances_,
    index=X.columns
).sort_values(ascending=False)

print(rf_importance)

# Investigate the relationship between SBP and hypertension stage
print("\nSBP VALUES AND HYPERTENSION STAGES")
print("----------------------------------")

sbp_stage_table = pd.crosstab(
    df["SBP"],
    df["level"]
)

print(sbp_stage_table)

# Count the number of different stages associated with each SBP value
print("\nNumber of stages per SBP value:")
print((sbp_stage_table > 0).sum(axis=1))
# Inspect the SBP values and related columns
print("\nSBP UNIQUE VALUES")
print(df["SBP"].value_counts().sort_index())

print("\nSAMPLE DATA RECORDS")
print(df[["age", "BMI", "SBP", "DBP", "level"]].head(10))

# Check whether any remaining feature closely matches the target
print("\nCHECKING FEATURES FOR POSSIBLE TARGET LEAKAGE")
print("==============================================")

features_to_check = [
    "age", "sex", "BMI", "Resi", "DBP",
    "Smoking", "odisease", "creantine", "BUN", "Noofmed"
]

for column in features_to_check:
    print(f"\n{column} compared with level:")
    print(pd.crosstab(df[column], df["level"]))
