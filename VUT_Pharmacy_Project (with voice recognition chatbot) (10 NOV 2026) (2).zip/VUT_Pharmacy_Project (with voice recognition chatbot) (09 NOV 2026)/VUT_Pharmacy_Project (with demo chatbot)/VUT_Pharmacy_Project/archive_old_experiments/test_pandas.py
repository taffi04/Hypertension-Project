
import pandas as pd

print("Pandas installed successfully!")

data = {
    "Name": ["Patient 1", "Patient 2", "Patient 3"],
    "Age": [21, 35, 65],
    "BMI": [22.83, 24.5, 30.5]
}

df = pd.DataFrame(data)

print(df)
