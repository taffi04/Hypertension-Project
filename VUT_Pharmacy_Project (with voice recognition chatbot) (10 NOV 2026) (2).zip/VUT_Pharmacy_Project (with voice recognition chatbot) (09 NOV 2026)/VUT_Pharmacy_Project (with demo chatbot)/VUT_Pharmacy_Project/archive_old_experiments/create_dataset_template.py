
import csv
import os

# Locate the main project folder
project_folder = os.path.dirname(os.path.abspath(__file__))

# Name of the CSV template
file_path = os.path.join(
    project_folder,
    "hypertension_dataset_template.csv"
)

# Original 10 features plus target and documentation fields
columns = [
    "record_id",
    "age",
    "smoking_status",
    "BMI",
    "salt_intake_score",
    "stress_score",
    "BP_history",
    "sleep_duration",
    "medication",
    "family_history",
    "exercise_level_score",
    "systolic_bp",
    "diastolic_bp",
    "hypertension_stage",
    "measurement_source",
    "label_guideline"
]

# Create the CSV with column headings only
with open(file_path, "w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(columns)

print("CSV template created successfully!")
print("Location:", file_path)
print("Number of columns:", len(columns))
print("Patient records added: 0")
