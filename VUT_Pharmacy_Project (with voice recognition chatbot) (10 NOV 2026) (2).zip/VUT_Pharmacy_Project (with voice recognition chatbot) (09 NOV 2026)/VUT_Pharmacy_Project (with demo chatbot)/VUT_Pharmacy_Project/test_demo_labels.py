
import csv
import os
from collections import Counter

project_folder = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(
    project_folder,
    "synthetic_hypertension_demo.csv"
)


def expected_demo_grade(systolic, diastolic):
    if systolic >= 180 or diastolic >= 110:
        return "Grade_3"
    elif systolic >= 160 or diastolic >= 100:
        return "Grade_2"
    elif systolic >= 140 or diastolic >= 90:
        return "Grade_1"
    else:
        return "Outside_target_grades"


if not os.path.exists(file_path):
    print("ERROR: Dataset file not found!")
    print("Expected file:", file_path)
else:
    with open(file_path, "r", newline="", encoding="utf-8") as file:
        records = list(csv.DictReader(file))

    print("Dataset loaded successfully!")
    print("Total records:", len(records))

    label_counts = Counter()
    mismatches = []

    for row in records:
        systolic = int(row["systolic_bp"])
        diastolic = int(row["diastolic_bp"])
        saved_label = row["hypertension_stage"]

        expected_label = expected_demo_grade(systolic, diastolic)
        label_counts[saved_label] += 1

        if saved_label != expected_label:
            mismatches.append({
                "record_id": row["record_id"],
                "saved": saved_label,
                "expected": expected_label
            })

    print("\nCategory counts:")
    for label, count in sorted(label_counts.items()):
        print(f"{label}: {count}")

    print("\nLabel consistency test:")
    if mismatches:
        print("FAILED:", len(mismatches), "incorrect labels found.")
        for item in mismatches[:10]:
            print(item)
    else:
        print("PASSED: All labels match the provisional rules.")

    print("\nNote: This tests coding consistency only.")
    print("It does not establish clinical validity.")
