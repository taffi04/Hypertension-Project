
import pandas as pd

results = pd.DataFrame({
    "Model": ["Decision Tree", "Random Forest"],
    "Test_Accuracy": [0.80, 0.60],
    "Correct_Predictions": [16, 12],
    "Total_Test_Records": [20, 20],
    "Dataset_Type": [
        "Synthetic demonstration",
        "Synthetic demonstration"
    ]
})

output_file = "model_comparison_results.csv"
results.to_csv(output_file, index=False)

print("Model comparison saved successfully!")
print("\nResults:")
print(results.to_string(index=False))
print("\nSaved to:", output_file)
print(
    "\nImportant: Results come from a small synthetic dataset "
    "and are not clinical validation."
)

