import streamlit as st
import joblib
import pandas as pd
from risk_assessment import assess_risk_factors, assess_blood_pressure
from hypertension_chatbot import show_hypertension_chatbot

# -------------------------------
# Page configuration
# -------------------------------
st.set_page_config(
    page_title="VUT Pharmacy | Hypertension Demo",
    page_icon="🩺",
    layout="wide"
)

# -------------------------------
# Professional styling
# -------------------------------
st.markdown("""

<style>
    .stApp {
        background-color: #FFF0F3;
        color: #4A1725;
    }

    .main-title {
        background: linear-gradient(120deg, #E6395B, #F7A1B5);
        padding: 28px;
        border-radius: 16px;
        color: white;
        margin-bottom: 22px;
        box-shadow: 0 4px 14px rgba(190, 35, 75, 0.12);
    }

    .main-title h1 {
        color: white;
        margin-bottom: 8px;
    }

    .main-title p {
        color: #FFF0F3;
        font-size: 17px;
    }

    div.stButton > button {
        background: linear-gradient(120deg, #D81B48, #EF476F);
        color: white;
        border-radius: 10px;
        border: none;
        padding: 12px 20px;
        font-weight: 600;
        width: 100%;
    }

    div.stButton > button:hover {
        background: #B9153A;
        color: white;
    }

    .disclaimer {
        background-color: #FFE0E8;
        border-left: 5px solid #E6395B;
        padding: 14px;
        border-radius: 8px;
        color: #65172B;
    }

    div[data-testid="stForm"],
    div[data-testid="stVerticalBlockBorderWrapper"] {
        border-color: #F5B7C7;
        border-radius: 14px;
    }

    h1, h2, h3 {
        color: #A4133C;
    }
</style>


""", unsafe_allow_html=True)

# -------------------------------
# Load saved model
# -------------------------------
model = joblib.load("decision_tree_model.joblib")

# -------------------------------
# Header
# -------------------------------
st.markdown("""
<div class="main-title">
    <h1>🩺 VUT Pharmacy</h1>
    <p>Hypertension Classification Demonstration</p>
    <p>Machine learning • Python • Educational project</p>
</div>
""", unsafe_allow_html=True)

st.markdown("""
<div class="disclaimer">
<strong>EDUCATIONAL DEMONSTRATION ONLY</strong><br>
This model uses synthetic data and provisional rule-generated
labels. It has not been clinically validated and must not be used
for diagnosis, treatment, or medical decisions.
</div>
""", unsafe_allow_html=True)

st.write("")
st.write(
    "Enter example information below to explore how the "
    "experimental model produces a demonstration category."
)

# -------------------------------
# Input form
# -------------------------------
with st.form("prediction_form"):
    st.subheader("1. Personal details")
    personal_col1, personal_col2 = st.columns(2)

    with personal_col1:
        age = st.number_input(
            "Age (years)",
            min_value=18,
            max_value=100,
            value=40
        )

    with personal_col2:
        bmi = st.number_input(
            "BMI",
            min_value=10.0,
            max_value=70.0,
            value=25.0,
            step=0.1
        )

    st.divider()
    st.subheader("2. Lifestyle features")
    lifestyle_col1, lifestyle_col2 = st.columns(2)

    with lifestyle_col1:
        smoking_status = st.selectbox(
            "Smoking status",
            ["Never", "Former", "Current", "Unknown"]
        )

        salt_intake_score = st.slider(
            "Salt intake score (0–6)",
            0, 6, 3
        )

        stress_score = st.slider(
            "Stress score (0–20)",
            0, 20, 10
        )

    with lifestyle_col2:
        sleep_duration = st.number_input(
            "Sleep duration (hours)",
            min_value=0.0,
            max_value=24.0,
            value=7.0,
            step=0.5
        )

        exercise_level_score = st.selectbox(
            "Exercise level score",
            [0, 1, 2, 3],
            format_func=lambda value: {
                0: "0 - Lowest",
                1: "1 - Low",
                2: "2 - Moderate",
                3: "3 - Highest"
            }[value]
        )

    st.divider()
    st.subheader("3. Health history")
    history_col1, history_col2 = st.columns(2)

    with history_col1:
        bp_history = st.selectbox(
            "Previous hypertension diagnosis",
            [
                "Previously_diagnosed",
                "Not_previously_diagnosed",
                "Unknown"
            ]
        )

        medication = st.selectbox(
            "Medication status",
            [
                "No_medication",
                "Antihypertensive_only",
                "Other_medication_only",
                "Both",
                "Unknown"
            ]
        )

    with history_col2:
        family_history = st.selectbox(
            "Family history",
            ["Yes", "No", "Unknown"]
        )
        st.divider()
    st.subheader("4. Blood-pressure reading")

    bp_col1, bp_col2 = st.columns(2)

    with bp_col1:
        systolic_bp = st.number_input(
            "Systolic blood pressure (mmHg)",
            min_value=50,
            max_value=300,
            value=120
)

    with bp_col2:
        diastolic_bp = st.number_input(
            "Diastolic blood pressure (mmHg)",
            min_value=30,
            max_value=200,
            value=80
)
    st.write("")
    submitted = st.form_submit_button(
        "Run demonstration prediction"
    )


# -------------------------------
# Display educational assessment
# -------------------------------
if submitted:
    
    # Prepare the submitted inputs in the same format used for training
    input_data = pd.DataFrame([{
        "age": age,
        "smoking_status": smoking_status,
        "BMI": bmi,
        "salt_intake_score": salt_intake_score,
        "stress_score": stress_score,
        "BP_history": bp_history,
        "sleep_duration": sleep_duration,
        "medication": medication,
        "family_history": family_history,
        "exercise_level_score": exercise_level_score,
        "systolic_bp": systolic_bp,
        "diastolic_bp": diastolic_bp
    }])

    # Generate the experimental machine-learning prediction
    prediction = model.predict(input_data)[0]

    st.subheader("Experimental Decision Tree prediction")
    st.info(f"Predicted demonstration category: {prediction}")

    st.caption(
        "This prediction reproduces patterns in a small synthetic "
        "dataset. It is not a clinical diagnosis."
    )

    # Calculate the educational risk-factor score
    score, category, reasons = assess_risk_factors(
        age=age,
        bmi=bmi,
        smoking_status=smoking_status,
        salt_intake_score=salt_intake_score,
        sleep_duration=sleep_duration,
        exercise_level_score=exercise_level_score,
        family_history=family_history
    )

    # Assess the entered blood pressure separately
    bp_category, bp_message = assess_blood_pressure(
        systolic_bp=systolic_bp,
        diastolic_bp=diastolic_bp
    )
    
    # Save assessment results so they survive Streamlit reruns
    st.session_state["current_assessment"] = {
        "risk_factor_score": f"{score}/7",
        "risk_category": category,
        "risk_factors": reasons,
        "systolic_bp": systolic_bp,
        "diastolic_bp": diastolic_bp,
        "bp_category": bp_category,
        "bp_message": bp_message,
    }


    st.divider()
    st.header("4. Educational assessment results")

    st.subheader("Risk-factor score")
    st.metric("Demonstration score", f"{score} / 7")
    st.info(f"**{category}**")

    st.write("Factors contributing to this score:")
    if reasons:
        for reason in reasons:
            st.write(f"- {reason}")
    else:
        st.write("No points were assigned by the demonstration rules.")

    st.caption(
        "This score is an illustrative classroom exercise, "
        "not a validated prediction of future hypertension."
    )

    st.divider()
    st.subheader("Blood-pressure reading")

    st.write(f"**Systolic:** {systolic_bp} mmHg")
    st.write(f"**Diastolic:** {diastolic_bp} mmHg")
    st.warning(f"**{bp_category}**")
    st.write(bp_message)

    st.caption(
        "A single reading cannot establish or rule out a diagnosis. "
        "Use appropriate repeat measurements and professional advice."
    )
    
    st.divider()

    

st.divider()




# -------------------------------
# AI Hypertension Assistant
# -------------------------------
if "current_assessment" in st.session_state:

    st.divider()
    st.subheader("AI Hypertension Assistant")

    show_hypertension_chatbot(
        current_assessment=st.session_state["current_assessment"]
    )

st.divider()

st.caption(
    "VUT Pharmacy Project | Educational demonstration only"
)

