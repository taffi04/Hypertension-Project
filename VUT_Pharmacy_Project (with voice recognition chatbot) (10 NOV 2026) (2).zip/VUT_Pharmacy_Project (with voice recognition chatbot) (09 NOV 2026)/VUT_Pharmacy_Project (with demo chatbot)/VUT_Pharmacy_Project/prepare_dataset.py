
import pandas as pd

# Load the synthetic demonstration dataset
df = pd.read_csv("synthetic_hypertension_demo.csv")

# Use the provisional hypertension grade as the target
y = df["hypertension_stage"]

# Select the 10 proposed input features
feature_columns = [
    "age",
    "smoking_status",
    "BMI",
    "salt_intake_score",
    "stress_score",
    "BP_history",
    "sleep_duration",
    "medication",
    "family_history",
    "exercise_level_score"
]

X = df[feature_columns]

print("Dataset loaded successfully!")
print("Number of records:", len(df))
print("Number of input features:", X.shape[1])

print("\nFeature columns:")
print(X.columns.tolist())

print("\nTarget categories:")
print(y.value_counts())

print("\nFirst five feature records:")
print(X.head())

print("\nFirst five target labels:")
print(y.head())
