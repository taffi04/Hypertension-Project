
import pandas as pd
import os

project_folder = os.path.dirname(os.path.abspath(__file__))

csv_path = os.path.join(
    project_folder,
    "hypertension_dataset_template.csv"
)

df = pd.read_csv(csv_path)

print("DATASET TEMPLATE CHECK")
print("----------------------")

print("Number of columns:", len(df.columns))
print("Number of patient records:", len(df))

print("\nColumn names:")
for column in df.columns:
    print("-", column)

expected_columns = [
    "record_id",
    "age",
    "smoking_status",
    "BMI",
    "salt_intake_score",
    "stress_score",
    "BP_history",
    "sleep_duration",
    "medication",
    "family_history",
    "exercise_level_score",
    "systolic_bp",
    "diastolic_bp",
    "hypertension_stage",
    "measurement_source",
    "label_guideline"
]

if list(df.columns) == expected_columns:
    print("\nSUCCESS: All 16 columns are correct.")
else:
    print("\nWARNING: The columns do not match.")
    print("Please check create_dataset_template.py.")
