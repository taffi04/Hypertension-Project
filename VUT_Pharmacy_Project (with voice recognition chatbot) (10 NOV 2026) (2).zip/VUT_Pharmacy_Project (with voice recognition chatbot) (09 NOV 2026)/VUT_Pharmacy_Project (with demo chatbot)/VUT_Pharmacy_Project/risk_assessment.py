
def assess_risk_factors(
    age,
    bmi,
    smoking_status,
    salt_intake_score,
    sleep_duration,
    exercise_level_score,
    family_history
):
    """
    Classroom demonstration only.
    This score is NOT a validated medical risk calculator.
    """

    score = 0
    reasons = []

    # 1. Age
    if age >= 45:
        score += 1
        reasons.append("Age 45 or older: +1")

    # 2. BMI
    if bmi >= 25:
        score += 1
        reasons.append("BMI of 25 or above: +1")

    # 3. Smoking
    if smoking_status == "Current":
        score += 1
        reasons.append("Current smoking: +1")

    # 4. Salt intake
    if salt_intake_score >= 4:
        score += 1
        reasons.append("Higher salt-intake score: +1")

    # 5. Sleep duration
    if sleep_duration < 7:
        score += 1
        reasons.append("Less than 7 hours of sleep: +1")

    # 6. Exercise
    if exercise_level_score <= 1:
        score += 1
        reasons.append("Lower exercise score: +1")

    # 7. Family history
    if family_history == "Yes":
        score += 1
        reasons.append("Family history reported: +1")

    # Demonstration categories only
    if score <= 2:
        category = "Lower demonstration score"
    elif score <= 4:
        category = "Moderate demonstration score"
    else:
        category = "Higher demonstration score"

    return score, category, reasons


def assess_blood_pressure(systolic_bp, diastolic_bp):
    if systolic_bp >= 180 or diastolic_bp >= 120:
        return (
            "VERY HIGH READING — URGENT ATTENTION",
            "Repeat the measurement after at least 1 minute. "
            "Seek urgent medical advice. If you have chest pain, "
            "shortness of breath, weakness, numbness, vision changes "
            "or difficulty speaking, seek emergency care."
        )

    elif systolic_bp >= 140 or diastolic_bp >= 90:
        return (
            "HIGH READING — REVIEW ADVISED",
            "This blood-pressure reading is high. Arrange a healthcare "
            "assessment and appropriate repeat measurements."
        )

    elif systolic_bp >= 130 or diastolic_bp >= 80:
        return (
            "ABOVE OPTIMAL RANGE — REVIEW ADVISED",
            "This reading is above the optimal range under some "
            "guidelines. Discuss it with a healthcare professional."
        )

    else:
        return (
            "BELOW THE DEMONSTRATION THRESHOLD",
            "This reading is below the thresholds used by this "
            "demonstration. One reading cannot rule out hypertension."
        )



