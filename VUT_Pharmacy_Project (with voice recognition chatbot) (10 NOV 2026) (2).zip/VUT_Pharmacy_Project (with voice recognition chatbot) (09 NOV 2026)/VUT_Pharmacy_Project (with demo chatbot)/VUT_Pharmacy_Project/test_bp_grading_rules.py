
def assign_demo_grade(systolic, diastolic):
    if systolic >= 180 or diastolic >= 110:
        return "Grade_3"
    elif systolic >= 160 or diastolic >= 100:
        return "Grade_2"
    elif systolic >= 140 or diastolic >= 90:
        return "Grade_1"
    else:
        return "Outside_target_grades"


test_cases = [
    (145, 85, "Grade_1"),
    (130, 95, "Grade_1"),
    (165, 85, "Grade_2"),
    (135, 105, "Grade_2"),
    (185, 80, "Grade_3"),
    (130, 115, "Grade_3"),
    (120, 80, "Outside_target_grades"),
]

passed = 0

for systolic, diastolic, expected in test_cases:
    actual = assign_demo_grade(systolic, diastolic)
    result = "PASS" if actual == expected else "FAIL"

    print(
        f"BP {systolic}/{diastolic}: "
        f"Expected {expected}, got {actual} - {result}"
    )

    if actual == expected:
        passed += 1

print(f"\nTests passed: {passed}/{len(test_cases)}")
