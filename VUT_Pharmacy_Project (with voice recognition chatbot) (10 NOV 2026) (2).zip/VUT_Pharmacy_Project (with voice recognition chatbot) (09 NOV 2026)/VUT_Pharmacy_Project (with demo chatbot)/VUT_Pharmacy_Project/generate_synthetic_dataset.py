
import csv
import os
import random

# Reproducible artificial data for software testing only
random.seed(42)

project_folder = os.path.dirname(os.path.abspath(__file__))

file_path = os.path.join(
    project_folder,
    "synthetic_hypertension_dataset.csv"
)

columns = [
    "record_id",
    "age",
    "smoking_status",
    "BMI",
    "salt_intake_score",
    "stress_score",
    "BP_history",
    "sleep_duration",
    "medication",
    "family_history",
    "exercise_level_score",
    "systolic_bp",
    "diastolic_bp",
    "hypertension_stage",
    "measurement_source",
    "label_guideline"
]

with open(file_path, "w", newline="", encoding="utf-8") as file:
    writer = csv.DictWriter(file, fieldnames=columns)
    writer.writeheader()

    for i in range(1, 101):
        writer.writerow({
            "record_id": f"SYN{i:03d}",
            "age": random.randint(18, 85),
            "smoking_status": random.choice(
                ["Never", "Former", "Current", "Unknown"]
            ),
            "BMI": round(random.uniform(18, 40), 1),
            "salt_intake_score": random.randint(0, 6),
            "stress_score": random.randint(0, 20),
            "BP_history": random.choice([
                "Previously_diagnosed",
                "Not_previously_diagnosed",
                "Unknown"
            ]),
            "sleep_duration": round(random.uniform(4, 10), 1),
            "medication": random.choice([
                "None",
                "Antihypertensive_only",
                "Other_medication_only",
                "Both",
                "Unknown"
            ]),
            "family_history": random.choice([
                "Yes", "No", "Unknown"
            ]),
            "exercise_level_score": random.randint(0, 3),
            "systolic_bp": "",
            "diastolic_bp": "",
            "hypertension_stage": "Unassigned",
            "measurement_source": "Synthetic_test_data",
            "label_guideline": "Not_assigned_synthetic_data"
        })

print("Synthetic test dataset created!")
print("File:", file_path)
print("Artificial records:", 100)
print("Clinical labels assigned: 0")
