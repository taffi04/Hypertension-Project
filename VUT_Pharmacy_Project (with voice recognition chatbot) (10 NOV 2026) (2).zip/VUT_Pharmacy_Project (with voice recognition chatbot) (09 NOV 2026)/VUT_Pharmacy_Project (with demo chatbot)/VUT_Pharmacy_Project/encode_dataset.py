
import pandas as pd

from sklearn.preprocessing import OneHotEncoder

# Load the synthetic dataset
df = pd.read_csv("synthetic_hypertension_demo.csv")

# Select the 10 proposed input features
feature_columns = [
    "age",
    "smoking_status",
    "BMI",
    "salt_intake_score",
    "stress_score",
    "BP_history",
    "sleep_duration",
    "medication",
    "family_history",
    "exercise_level_score"
]

X = df[feature_columns]
y = df["hypertension_stage"]

# Identify text-based categorical columns
categorical_columns = [
    "smoking_status",
    "BP_history",
    "medication",
    "family_history"
]

# Encode categorical features as numeric columns
encoder = OneHotEncoder(
    handle_unknown="ignore",
    sparse_output=False
)

encoded_array = encoder.fit_transform(
    X[categorical_columns]
)

encoded_columns = encoder.get_feature_names_out(
    categorical_columns
)

encoded_df = pd.DataFrame(
    encoded_array,
    columns=encoded_columns
)

# Keep numeric features and combine them with encoded features
numeric_columns = [
    column for column in feature_columns
    if column not in categorical_columns
]

X_encoded = pd.concat(
    [
        X[numeric_columns].reset_index(drop=True),
        encoded_df.reset_index(drop=True)
    ],
    axis=1
)

print("Encoding completed successfully!")
print("Original feature count:", X.shape[1])
print("Encoded feature count:", X_encoded.shape[1])
print("Target categories:", sorted(y.unique()))

print("\nEncoded feature names:")
print(X_encoded.columns.tolist())

print("\nFirst five encoded records:")
print(X_encoded.head())

print("\nMissing values after encoding:")
print(X_encoded.isnull().sum().sum())
