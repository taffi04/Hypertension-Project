
import pandas as pd

from sklearn.model_selection import train_test_split

# Load the encoded dataset
df = pd.read_csv("synthetic_hypertension_demo.csv")

feature_columns = [
    "age",
    "smoking_status",
    "BMI",
    "salt_intake_score",
    "stress_score",
    "BP_history",
    "sleep_duration",
    "medication",
    "family_history",
    "exercise_level_score"
]

X = df[feature_columns]
y = df["hypertension_stage"]

# Split into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

print("Dataset split successfully!")

print("\nTraining records:", len(X_train))
print("Testing records:", len(X_test))

print("\nTraining target distribution:")
print(y_train.value_counts())

print("\nTesting target distribution:")
print(y_test.value_counts())

print("\nTraining and testing records combined:",
      len(X_train) + len(X_test))
