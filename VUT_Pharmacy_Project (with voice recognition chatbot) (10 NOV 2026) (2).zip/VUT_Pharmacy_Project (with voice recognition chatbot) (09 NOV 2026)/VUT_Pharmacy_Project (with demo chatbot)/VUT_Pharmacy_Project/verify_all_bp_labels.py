
import pandas as pd

# Load the synthetic demonstration dataset
df = pd.read_csv("synthetic_hypertension_demo.csv")

# Recalculate the expected grade for each record
def assign_demo_grade(systolic, diastolic):
    if systolic >= 180 or diastolic >= 110:
        return "Grade_3"
    elif systolic >= 160 or diastolic >= 100:
        return "Grade_2"
    elif systolic >= 140 or diastolic >= 90:
        return "Grade_1"
    else:
        return "Outside_target_grades"

df["expected_grade"] = df.apply(
    lambda row: assign_demo_grade(
        row["systolic_bp"],
        row["diastolic_bp"]
    ),
    axis=1
)

# Compare saved labels against recalculated labels
df["label_matches"] = (
    df["hypertension_stage"] == df["expected_grade"]
)

mismatches = df[~df["label_matches"]]

print("Total records checked:", len(df))
print("Matching labels:", df["label_matches"].sum())
print("Mismatched labels:", len(mismatches))

if len(mismatches) == 0:
    print("SUCCESS: All labels match the grading rules.")
else:
    print("Records with mismatched labels:")
    print(mismatches[
        ["record_id", "systolic_bp", "diastolic_bp",
         "hypertension_stage", "expected_grade"]
    ])
