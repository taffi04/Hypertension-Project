
import csv
import os

project_folder = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(
    project_folder,
    "synthetic_hypertension_demo.csv"
)

with open(file_path, "r", newline="", encoding="utf-8") as file:
    records = list(csv.DictReader(file))

print("Total records:", len(records))

required_columns = [
    "record_id",
    "age",
    "BMI",
    "systolic_bp",
    "diastolic_bp",
    "hypertension_stage"
]

print("\nMissing values:")
for column in required_columns:
    missing = sum(
        1 for row in records
        if not row.get(column, "").strip()
    )
    print(f"{column}: {missing}")

record_ids = [row["record_id"] for row in records]
print("\nDuplicate record IDs:",
      len(record_ids) - len(set(record_ids)))

systolic = [int(row["systolic_bp"]) for row in records]
diastolic = [int(row["diastolic_bp"]) for row in records]

print("\nBlood pressure summary:")
print("Systolic minimum:", min(systolic))
print("Systolic maximum:", max(systolic))
print("Diastolic minimum:", min(diastolic))
print("Diastolic maximum:", max(diastolic))

print("\nDataset checks completed.")
