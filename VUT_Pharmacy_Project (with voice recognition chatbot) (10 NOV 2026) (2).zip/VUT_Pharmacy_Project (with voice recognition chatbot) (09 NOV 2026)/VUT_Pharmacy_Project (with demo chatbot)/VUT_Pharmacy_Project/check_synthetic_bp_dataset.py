
import pandas as pd
import os

project_folder = os.path.dirname(os.path.abspath(__file__))

file_path = os.path.join(
    project_folder,
    "synthetic_hypertension_demo.csv"
)

df = pd.read_csv(file_path)
print("CSV being checked:", file_path)
print("Medication values from pandas:")
print(df["medication"].head(10).tolist())
print("Blank medication count:", df["medication"].isna().sum())

print("Dataset loaded successfully!")
print("Dataset shape:", df.shape)

print("\nFirst five records:")
print(df.head().to_string(index=False))

print("\nNumber of records per demonstration grade:")
print(df["hypertension_stage"].value_counts())

print("\nMissing values per column:")
print(df.isnull().sum())

print("\nMeasurement sources:")
print(df["measurement_source"].value_counts())

print("\nLabel documentation:")
print(df["label_guideline"].value_counts())

print("\nAre all records marked as synthetic?")
print(
    (df["measurement_source"] == "Synthetic_test_data").all()
)

print("\nAre all blood pressure readings present?")
print(
    df[["systolic_bp", "diastolic_bp"]]
    .notnull()
    .all()
    .all()
)

print("\nMedication values including missing entries:")
print(df["medication"].value_counts(dropna=False))

print("\nRows with missing medication:")
print(
    df.loc[
        df["medication"].isna(),
        ["record_id", "medication", "measurement_source"]
    ].to_string(index=False)
)
