
import csv
import os
import random

# SYNTHETIC DATA FOR SOFTWARE TESTING ONLY.
# These are artificial records, not real patient data.
# Grades use provisional rules, not a validated AI model.

random.seed(42)

project_folder = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(
    project_folder,
    "synthetic_hypertension_demo.csv"
)

columns = [
    "record_id", "age", "smoking_status", "BMI",
    "salt_intake_score", "stress_score", "BP_history",
    "sleep_duration", "medication", "family_history",
    "exercise_level_score", "systolic_bp", "diastolic_bp",
    "hypertension_stage", "measurement_source", "label_guideline"
]


def assign_demo_grade(systolic, diastolic):
    if systolic >= 180 or diastolic >= 110:
        return "Grade_3"
    elif systolic >= 160 or diastolic >= 100:
        return "Grade_2"
    elif systolic >= 140 or diastolic >= 90:
        return "Grade_1"
    else:
        return "Outside_target_grades"


with open(file_path, "w", newline="", encoding="utf-8") as file:
    writer = csv.DictWriter(file, fieldnames=columns)
    writer.writeheader()

    for i in range(1, 101):
        systolic = random.randint(105, 205)
        diastolic = random.randint(65, 125)

        grade = assign_demo_grade(systolic, diastolic)

        medication_value = random.choice([
    "No_medication",
    "Antihypertensive_only",
    "Other_medication_only",
    "Both",
    "Unknown"
])

        if not medication_value:
            medication_value = "Unknown"

        row = {
            "record_id": f"SYN{i:03d}",
            "age": random.randint(18, 85),
            "smoking_status": random.choice(
                ["Never", "Former", "Current", "Unknown"]
            ),
            "BMI": round(random.uniform(18, 40), 1),
            "salt_intake_score": random.randint(0, 6),
            "stress_score": random.randint(0, 20),
            "BP_history": random.choice([
                "Previously_diagnosed",
                "Not_previously_diagnosed",
                "Unknown"
            ]),
            "sleep_duration": round(random.uniform(4, 10), 1),
            "medication": medication_value,
            "family_history": random.choice(["Yes", "No", "Unknown"]),
            "exercise_level_score": random.randint(0, 3),
            "systolic_bp": systolic,
            "diastolic_bp": diastolic,
            "hypertension_stage": grade,
            "measurement_source": "Synthetic_test_data",
            "label_guideline":
                "Provisional_rule_based_demo_not_clinically_validated"
        }

        writer.writerow(row)

print("Synthetic demonstration dataset created!")
print("File:", file_path)
print("Artificial records:", 100)
print("Real patient records: 0")
print("Labels assigned using provisional BP rules.")
print("Clinical validation: NOT performed.")

