
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report

# Load synthetic demonstration data
df = pd.read_csv("synthetic_hypertension_demo.csv")

# Select the 10 proposed input features

feature_columns = [
    "age",
    "smoking_status",
    "BMI",
    "salt_intake_score",
    "stress_score",
    "BP_history",
    "sleep_duration",
    "medication",
    "family_history",
    "exercise_level_score",
    "systolic_bp",
    "diastolic_bp"
]


X = df[feature_columns]
y = df["hypertension_stage"]

# Identify categorical and numeric features
categorical_columns = [
    "smoking_status",
    "BP_history",
    "medication",
    "family_history"
]


numeric_columns = [
    "age",
    "BMI",
    "salt_intake_score",
    "stress_score",
    "sleep_duration",
    "exercise_level_score",
    "systolic_bp",
    "diastolic_bp"
]


# Split the data before preprocessing
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

# Preprocess features
preprocessor = ColumnTransformer(
    transformers=[
        (
            "categorical",
            OneHotEncoder(handle_unknown="ignore"),
            categorical_columns
        ),
        ("numeric", "passthrough", numeric_columns)
    ]
)

# Build the Decision Tree pipeline
model = Pipeline(
    steps=[
        ("preprocessing", preprocessor),
        ("classifier", DecisionTreeClassifier(random_state=42))
    ]
)

# Train the model
model.fit(X_train, y_train)
joblib.dump(model, "decision_tree_model.joblib")
print("Decision Tree model saved successfully!")

# Predict the test set
predictions = model.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, predictions)

print("Decision Tree trained successfully!")
print("Training records:", len(X_train))
print("Testing records:", len(X_test))
print(f"Test accuracy: {accuracy:.2%}")

print("\nClassification report:")
print(
    classification_report(
        y_test,
        predictions,
        zero_division=0
    )
)
