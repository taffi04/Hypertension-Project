
import pandas as pd

df = pd.read_csv("synthetic_hypertension_demo.csv")

print("=== NUMERIC FEATURE SUMMARY ===")
columns = [
    "age",
    "BMI",
    "salt_intake_score",
    "stress_score",
    "sleep_duration",
    "exercise_level_score",
    "systolic_bp",
    "diastolic_bp"
]

print(df[columns].describe().round(2))

print("\n=== CATEGORICAL FEATURE VALUES ===")
categorical_columns = [
    "smoking_status",
    "BP_history",
    "medication",
    "family_history"
]

for column in categorical_columns:
    print(f"\n{column}:")
    print(df[column].value_counts(dropna=False))

print("\n=== MISSING VALUES ===")
print(df[columns + categorical_columns].isnull().sum())


