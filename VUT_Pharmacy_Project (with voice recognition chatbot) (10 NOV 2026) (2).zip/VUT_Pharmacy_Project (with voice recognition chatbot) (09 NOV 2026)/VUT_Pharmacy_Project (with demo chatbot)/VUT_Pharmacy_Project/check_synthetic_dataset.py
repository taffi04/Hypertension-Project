
import csv
import os

project_folder = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(
    project_folder,
    "synthetic_hypertension_dataset.csv"
)

with open(file_path, "r", newline="", encoding="utf-8") as file:
    reader = csv.DictReader(file)
    rows = list(reader)
    columns = reader.fieldnames

print("Dataset loaded successfully!")
print("Number of records:", len(rows))
print("Number of columns:", len(columns))
print("\nColumn names:")
print(columns)

print("\nFirst 5 records:")
for row in rows[:5]:
    print(row)

print("\nClinical labels:")
labels = set(row["hypertension_stage"] for row in rows)
print(labels)

print("\nMeasurement sources:")
sources = set(row["measurement_source"] for row in rows)
print(sources)

import pandas as pd
import os

# Locate the synthetic dataset
project_folder = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(
    project_folder,
    "synthetic_hypertension_dataset.csv"
)

# Load the dataset
df = pd.read_csv(file_path)

print("Dataset loaded successfully!")
print("Dataset shape:", df.shape)

print("\nColumn names:")
print(df.columns.tolist())

print("\nFirst five records:")
print(df.head())

print("\nMissing values per column:")
print(df.isnull().sum())

print("\nClinical labels:")
print(df["hypertension_stage"].value_counts())

print("\nMeasurement sources:")
print(df["measurement_source"].value_counts())
